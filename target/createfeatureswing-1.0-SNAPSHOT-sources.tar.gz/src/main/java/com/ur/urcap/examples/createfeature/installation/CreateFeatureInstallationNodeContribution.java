package com.ur.urcap.examples.createfeature.installation;

import java.awt.EventQueue;
import java.util.Collection;
import java.util.Timer;
import java.util.TimerTask;

import com.ur.urcap.api.contribution.InstallationNodeContribution;
import com.ur.urcap.api.contribution.installation.InstallationAPIProvider;
import com.ur.urcap.api.domain.InstallationAPI;
import com.ur.urcap.api.domain.UserInterfaceAPI;
import com.ur.urcap.api.domain.data.DataModel;
import com.ur.urcap.api.domain.feature.Feature;
import com.ur.urcap.api.domain.feature.FeatureContributionModel;
import com.ur.urcap.api.domain.script.ScriptWriter;
import com.ur.urcap.api.domain.userinteraction.RobotPositionCallback2;
import com.ur.urcap.api.domain.value.jointposition.JointPositions;
import com.ur.urcap.api.domain.value.robotposition.PositionParameters;
import com.ur.urcap.api.domain.variable.Variable;
import com.ur.urcap.api.domain.variable.VariableModel;
import com.ur.urcap.api.domain.util.Filter;

public class CreateFeatureInstallationNodeContribution implements InstallationNodeContribution {
	private static final String FEATURE_KEY = "FeatureKey";
	private static final String FEATURE_JOINT_ANGLES_KEY = "jointAngles";
	private static final String SUGGESTED_FEATURE_NAME = "URCapFeature";
	private static final String SELECTED_VAR = "selectedVar";
	private final DataModel model;
	private final CreateFeatureInstallationNodeView view;
	private FeatureContributionModel featureContributionModel;
	private UserInterfaceAPI userInterfaceAPI;
	private InstallationAPI installAPI;
	private Timer uiTimer;
	private boolean pauseTimer = false;
	protected String response = "No response";

	CreateFeatureInstallationNodeContribution(InstallationAPIProvider apiProvider, DataModel model, CreateFeatureInstallationNodeView view) {

		this.model = model;
		this.view = view;
		this.installAPI = apiProvider.getInstallationAPI();
		featureContributionModel = apiProvider.getInstallationAPI().getFeatureContributionModel();
		userInterfaceAPI = apiProvider.getUserInterfaceAPI();
	}

	@Override
	public void openView() {
		view.featureIsCreated(isFeatureCreated());
		view.updateView(this);
	}

	@Override
	public void closeView() {
		if (uiTimer != null) {
			uiTimer.cancel();
		}
	}

	@Override
	public void generateScript(ScriptWriter writer) {
		// Intentionally left empty
	}

	public boolean isFeatureCreated() {
		return model.isSet(FEATURE_KEY);
	}

	public Feature getFeature() {
		return model.get(FEATURE_KEY, (Feature)null);
	}

	public JointPositions getFeatureJointPositions() {
		return model.get(FEATURE_JOINT_ANGLES_KEY, (JointPositions)null);
	}

	void createFeature() {
		userInterfaceAPI.getUserInteraction().getUserDefinedRobotPosition(new RobotPositionCallback2() {
			@Override
			public void onOk(PositionParameters positionParameters) {
				Feature feature = featureContributionModel.addFeature(FEATURE_KEY, SUGGESTED_FEATURE_NAME, positionParameters.getPose());
				model.set(FEATURE_KEY, feature);
				// joint positions are not part of the feature. They are only used by the program node, for creating waypoints
				model.set(FEATURE_JOINT_ANGLES_KEY, positionParameters.getJointPositions());
				view.featureIsCreated(true);
			}
		});
	}

	void updateFeature() {
		userInterfaceAPI.getUserInteraction().getUserDefinedRobotPosition(new RobotPositionCallback2() {
			@Override
			public void onOk(PositionParameters positionParameters) {
				featureContributionModel.updateFeature(FEATURE_KEY, positionParameters.getPose());
				model.set(FEATURE_JOINT_ANGLES_KEY, positionParameters.getJointPositions());
			}
		});

	}

	void deleteFeature() {
		featureContributionModel.removeFeature(FEATURE_KEY);
		model.remove(FEATURE_KEY);
		model.remove(FEATURE_JOINT_ANGLES_KEY);
		view.featureIsCreated(false);
	}

	public Collection<Variable> getInstallationVars() {
		return installAPI.getVariableModel().get(new Filter<Variable>() {
			@Override
			public boolean accept(Variable element) {
				return element.getType().equals(Variable.Type.VALUE_PERSISTED);
			}
		});
	}

	public Variable getSelectedVariable() {
		return model.get(SELECTED_VAR, (Variable) null);
	}

	public void setVariable(final Variable variable) {
		model.set(SELECTED_VAR, variable);
	}

	public void removeVariable() {
		model.remove(SELECTED_VAR);
	}

	public void getVarFromDashboard(){
		uiTimer = new Timer(true);
		uiTimer.schedule(new TimerTask() {
			@Override
			public void run() {
				EventQueue.invokeLater(new Runnable() {
					@Override
					public void run() {
						if (!pauseTimer) {
							System.out.println("Starting threaded server check.");
							VariableCollection vc = new VariableCollection();
							String response = vc.getVarVal(getSelectedVariable().toString());  // Replace YOUR_COMMAND_HERE with the actual command
							System.out.println("Response from server: " + response);
							view.updateVarLabel(response);
						}
					}
				});
			}
		}, 0, 1000);
		
	}
}
