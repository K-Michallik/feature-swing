package com.ur.urcap.examples.createfeature.installation;

// import com.ur.urcap.api.contribution.ContributionProvider;
import com.ur.urcap.api.contribution.installation.swing.SwingInstallationNodeView;
import com.ur.urcap.api.domain.variable.GlobalVariable;
import com.ur.urcap.api.domain.variable.Variable;
import com.ur.urcap.examples.createfeature.style.Style;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ItemListener;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;


public class CreateFeatureInstallationNodeView implements SwingInstallationNodeView<CreateFeatureInstallationNodeContribution> {
	private static final String DESCRIPTION_TXT = "<html>Create and modify an installation feature, that will be used in the Use Feature program node.<br/> " +
			"The created feature can be inspected in PolyScopes feature screen under the installation tab</html>";
	private static final String CREATE_FEATURE_TXT = "Create feature";
	private static final String UPDATE_FEATURE_TXT = "Update feature";
	private static final String DELETE_FEATURE_TXT = "Delete feature";

	private JButton createFeatureButton;
	private JButton updateFeatureButton;
	private JButton	deleteFeatureButton;
	
	private JLabel errorLabel = new JLabel();
	private JComboBox variablesComboBox = new JComboBox();
	private JLabel varLabel = new JLabel("Var:");
	private JButton getVarValButton;


	private final Style style;

	public CreateFeatureInstallationNodeView(Style style) {
		this.style = style;
	}

	@Override
	public void buildUI(JPanel panel, final CreateFeatureInstallationNodeContribution contribution) {
		panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

		Box content = Box.createVerticalBox();
		content.setAlignmentX(Component.LEFT_ALIGNMENT);
		content.setAlignmentY(Component.TOP_ALIGNMENT);
		content.add(createHeaderSection());
		content.add(createVerticalSpacing());
		content.add(createFeatureSection(contribution));
		content.add(createVerticalSpacing());
		content.add(createComboBox(contribution));
		content.add(createVerticalSpacing());
		content.add(varLabel);
		content.add(createVerticalSpacing());

		// Add getVarVal button
    	content.add(createGetVarValButton(contribution));
    	content.add(createVerticalSpacing());
		

		panel.add(content);
	}

	void featureIsCreated(boolean featureCreated) {
		createFeatureButton.setEnabled(!featureCreated);
		updateFeatureButton.setEnabled(featureCreated);
		deleteFeatureButton.setEnabled(featureCreated);
	}

	private Component createFeatureSection(CreateFeatureInstallationNodeContribution contribution) {
		Box section = Box.createHorizontalBox();
		section.setAlignmentX(Component.LEFT_ALIGNMENT);
		section.setAlignmentY(Component.TOP_ALIGNMENT);

		createFeatureButton = createCreateFeatureButton(contribution);
		section.add(createFeatureButton);
		section.add(createHorizontalSpacing());

		updateFeatureButton = createUpdateFeatureButton(contribution);
		section.add(updateFeatureButton);
		section.add(createHorizontalSpacing());

		deleteFeatureButton = createDeleteFeatureButton(contribution);
		section.add(deleteFeatureButton);

		return section;
	}

	private JButton createCreateFeatureButton(final CreateFeatureInstallationNodeContribution contribution) {
		JButton btn = new JButton(CREATE_FEATURE_TXT);
		btn.setFocusPainted(false);
		btn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				contribution.createFeature();
			}
		});
		return btn;
	}

	private JButton createUpdateFeatureButton(final CreateFeatureInstallationNodeContribution contribution) {
		JButton btn = new JButton(UPDATE_FEATURE_TXT);
		btn.setFocusPainted(false);
		btn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				contribution.updateFeature();
			}
		});
		return btn;
	}

	private JButton createDeleteFeatureButton(final CreateFeatureInstallationNodeContribution contribution) {
		JButton btn = new JButton(DELETE_FEATURE_TXT);
		btn.setFocusPainted(false);
		btn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				contribution.deleteFeature();
			}
		});
		return btn;
	}

	private Component createHorizontalSpacing() {
		return Box.createRigidArea(new Dimension(10, 0));
	}

	private Component createVerticalSpacing() {
		return Box.createRigidArea(new Dimension(0, 15));
	}

	private Box createHeaderSection() {
		Box section = Box.createHorizontalBox();
		section.setAlignmentX(Component.LEFT_ALIGNMENT);
		JLabel descriptionLabel = new JLabel(DESCRIPTION_TXT);
		section.add(descriptionLabel);
		return section;
	}

	private Box createComboBox(final CreateFeatureInstallationNodeContribution contribution) {
		Box inputBox = Box.createHorizontalBox();
		inputBox.setAlignmentX(Component.LEFT_ALIGNMENT);

		variablesComboBox.setFocusable(false);
		variablesComboBox.setPreferredSize(style.getComboBoxDimension());
		variablesComboBox.addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent itemEvent) {
				if (itemEvent.getStateChange() == ItemEvent.SELECTED) {
					if (itemEvent.getItem() instanceof Variable) {
						contribution.setVariable(((Variable) itemEvent.getItem()));
					} else {
						contribution.removeVariable();
					}
				}
			}
		});

		JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
		panel.add(variablesComboBox, BorderLayout.CENTER);

		inputBox.add(panel);
		return inputBox;
	}

	private JButton createGetVarValButton(final CreateFeatureInstallationNodeContribution contribution) {
		JButton button = new JButton("Get Variable Value");
		button.setFocusPainted(false);
		button.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				contribution.getVarFromDashboard();
			}
		});
		return button;
	}
	

	protected void updateVarLabel(String response){
		varLabel.setText(response);
	}


	private void updateVariablesComboBox(CreateFeatureInstallationNodeContribution contribution) {
		DefaultComboBoxModel model = new DefaultComboBoxModel();
		List<Variable> variables = getVariables(contribution);

		Variable selectedVariable = contribution.getSelectedVariable();
		if (selectedVariable != null) {
			model.setSelectedItem(selectedVariable);
		}
		model.addElement("<Variable>");

		for (Variable variable : variables) {
			model.addElement(variable);
		}

		variablesComboBox.setModel(model);
	}

	private List<Variable> getVariables(CreateFeatureInstallationNodeContribution contribution) {
		List<Variable> sortedVariables = new ArrayList<Variable>(contribution.getInstallationVars());

		Collections.sort(sortedVariables, new Comparator<Variable>() {
			@Override
			public int compare(Variable var1, Variable var2) {
				if (var1.toString().toLowerCase().compareTo(var2.toString().toLowerCase()) == 0) {
					//Sort lowercase/uppercase consistently
					return var1.toString().compareTo(var2.toString());
				} else {
					return var1.toString().toLowerCase().compareTo(var2.toString().toLowerCase());
				}
			}
		});

		return sortedVariables;
	}


	private void clearErrors() {
		errorLabel.setVisible(false);
	}

	public void updateView(CreateFeatureInstallationNodeContribution contribution) {
		clearErrors();
		updateVariablesComboBox(contribution);
	}
}
